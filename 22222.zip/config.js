module.exports = {
  bot: {
    owners: ["1005911266545651732","1153316197081821286","881213898416590888"],  // اونر
    botID: "1292834893998329896",    // ايدي البوت
    GuildId: "1167423199261241345",   // ايدي السيرفير
    ClientId: "1292834893998329896",    // ايدي البوت
    serverinvte: "https://discord.gg/sQvVXfPb", // انفايت سير
    clientSECRET: "rjLfvWAcUsTIuz-5_Pc_gTEuI8eSYpua", // سكريت
    callbackURL: "https://3d466463-6649-457d-aadf-75dce3ae3a07-00-l2f447mw4ril.picard.replit.dev/login", // الكال باك
    TheLinkVerfy : "https://discord.com/oauth2/authorize?client_id=1292834893998329896&response_type=code&redirect_uri=https%3A%2F%2F3d466463-6649-457d-aadf-75dce3ae3a07-00-l2f447mw4ril.picard.replit.dev%2Flogin&scope=identify+guilds+guilds.join", // رابط اوثو رايز بالصلاحيه ادخال الي سيرفرات
    prefix : '$', 
     TOKEN: ("MTI5MjgzNDg5Mzk5ODMyOTg5Ng.G73Hv_.JPdkaVFOMJMG98LmdPz-0sx9sz2Ka-ojBzY6iQ"),// توكن 
    TraId  : '881213898416590888', // الي يتحوله كريديت
    done : "1292865811471663105",//ايدي روم تمت العملية
    line : "https://cdn.discordapp.com/attachments/1167423199298998281/1292872727547609211/image.png?ex=6705510e&is=6703ff8e&hm=645bb907fade3962215bf0ab1fa4528e9e31ee34e146e413bed84540dcfcf630&",//رابط خط السيرفر
    stockimg : "https://cdn.discordapp.com/attachments/1167423199298998281/1292872344339091517/image.png?ex=670550b3&is=6703ff33&hm=38658037e2985d207c1baaf0a7daa18deff75e87e98af257f72edc91647f62af&",//رابط صوره ستوك الاعضاء
      supportimg : "https://cdn.discordapp.com/attachments/1167423199298998281/1292872659729649735/image.png?ex=670550fe&is=6703ff7e&hm=da5663a9fac4fe8b2c9b19d3af38db28f85c2e2a102c6b59e90672ec6600034a&",//رابط صوره تذكرة الدعم الفني
    ticketimg : "https://cdn.discordapp.com/attachments/1167423199298998281/1292872441676300460/image.png?ex=670550ca&is=6703ff4a&hm=f6705eca6bfae12e807a9eafa679f8e5030788f2b5ce9aeffb7a01d8a2046cf9&",//زابط صور تذكرة الشراء
    fedroom : "1167423199907164183",//ايدي روم الفيدباك
    clientrole : "1167423199261241351"//ايدي رتبه الزباين
  },
  website: {
    PORT: "3001",
  }
}