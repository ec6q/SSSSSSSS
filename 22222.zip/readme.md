# رابط الشرح :
# 

# سيرفر الدعم الفني : (https://discord.gg/thailandcodes)
